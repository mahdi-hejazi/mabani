<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {

        Schema::create('weekly_bus_schedules', function (Blueprint $table) {
            $table->id();
            $table->string('origin_city_code',5);
            $table->string('origin_terminal_code',5);
            $table->string('destination_city_code',5);
            $table->string('destination_terminal_code',5);

            $table->integer('bus_departure_day');  //day of weak 0 to 6
            $table->integer('bus_departure_time'); //seconds from 00:00 of day

            $table->integer('approximate_travel_time'); //in minute

            $table->integer('capacity');
            $table->string('type'); //type of buss ( number of seats )

            $table->integer('ticket_price');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('weekly_bus_schedules');
    }
};
