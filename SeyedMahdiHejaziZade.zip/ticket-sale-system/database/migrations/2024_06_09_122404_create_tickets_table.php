<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();

           $table->string('name')->nullable();
           $table->string('family')->nullable();
           $table->string('national_code')->nullable();
           $table->string('phone_number')->nullable();

            $table->unsignedBigInteger('travel_reservation_id');
            $table->foreign('travel_reservation_id')->references('id')->on('travel_reservations');

            $table->integer('seat_number')->nullable();

            $table->timestamp('canceled_at')->nullable();

            $table->timestamps();
            $table->unique(['seat_number', 'travel_reservation_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tickets');
    }
};
