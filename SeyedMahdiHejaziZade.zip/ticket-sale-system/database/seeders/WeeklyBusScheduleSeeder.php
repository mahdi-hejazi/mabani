<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class WeeklyBusScheduleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \App\Models\WeeklySchedule\WeeklyBusSchedule::factory(100)->create();
    }
}
