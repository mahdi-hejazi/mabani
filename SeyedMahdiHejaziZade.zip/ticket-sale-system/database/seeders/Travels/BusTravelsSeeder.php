<?php

namespace Database\Seeders\Travels;

use App\Models\WeeklySchedule\WeeklyBusSchedule;
use Illuminate\Database\Seeder;

class BusTravelsSeeder extends Seeder
{
    /**
     * add buses to travels
     *
     *  from first_date to last_date we add buses base on weekly schedule to travels
     *
     * add temp_date one by one
     * for each temp_date we see weekly_bus_schedule and add buses of that day of week to travels
     */
    public function run(): void
    {
        $weeklyBusSchedule=WeeklyBusSchedule::all();

        $first_date=today();
        $last_date=today()->addMonth(1);

        for ($temp_date=$first_date; $temp_date<$last_date; $temp_date->addDay(1)) {
            $buses=$weeklyBusSchedule->where('bus_departure_day',$temp_date->dayOfWeek);
            foreach ($buses as $bus) {
                $bus->travels()->create([
                    'date'=>$temp_date->addSecond($bus->bus_departure_time),
                    'status'=>'available'
                ]);
            }
        }
    }
}
