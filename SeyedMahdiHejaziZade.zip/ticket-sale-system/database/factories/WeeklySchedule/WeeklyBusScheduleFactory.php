<?php

namespace Database\Factories\WeeklySchedule;

use Illuminate\Database\Eloquent\Factories\Factory;

class WeeklyBusScheduleFactory extends Factory
{

    public function definition(): array
    {

//        11 fake city each with 2 terminal
        $array_city_terminal_terminal=[["abcde", "fghij", "klmno"], ["hijkl", "mnopq", "rstuv"], ["wxyza","sdred","rtdsg"],
            ["pqrst", "uvwxy", "zabcd"], ["efghi", "jklmn", "opqrs"], ["tuvwx", "yzabc", "defgh"],[ "ijklm", "nopqr", "stuvw"],
            ["xyzab", "cdefg", "hijkl"], ["mnopq", "rstuv", "wxyza"],[ "bcdef", "ghijk", "lmnop"], ["qrstw", "xyzab", "cdefg"]];

        $index_city_origin=rand(0,count($array_city_terminal_terminal)-1);
        $index_terminal_origin=rand(1,count($array_city_terminal_terminal[$index_city_origin])-1);

        $index_city_destination=rand(0,count($array_city_terminal_terminal)-1);
        while ($index_city_destination == $index_city_origin) {
            $index_city_destination=rand(0,count($array_city_terminal_terminal)-1);
        }
        $index_terminal_destination=rand(1,count($array_city_terminal_terminal[$index_city_destination])-1);
        return [
            'origin_city_code' => $array_city_terminal_terminal[$index_city_origin][0],
            'origin_terminal_code' => $array_city_terminal_terminal[$index_city_origin][$index_terminal_origin],
            'destination_city_code' => $array_city_terminal_terminal[$index_city_destination][0],
            'destination_terminal_code' => $array_city_terminal_terminal[$index_city_destination][$index_terminal_destination],
            'bus_departure_day' => fake()->numberBetween(0, 6),
            'bus_departure_time' => fake()->numberBetween(0, 86399), // seconds from midnight
            'approximate_travel_time' => fake()->numberBetween(30, 240), // in minutes
            'capacity' => fake()->numberBetween(20, 50),
            'type' => fake()->randomElement(['Standard', 'Luxury', 'Sleeper']),
            'ticket_price' => fake()->numberBetween(100, 500) * 10000,
        ];
    }
}
