## first run

Do following
- install php , composer
- go to directory and run "php composer install && php composer update"
- php artisan migrate

To insert fake data to db
- php artisan db:seed --class=WeeklyBusScheduleSeeder
make travels for one month from now - (only use one)
-  php artisan db:seed --class=Database\Seeders\Travels\BusTravelsSeeder



