<?php

namespace App\helper;

use App\Models\Travel\Travel;
use Illuminate\Support\Collection;

class travelHelper
{

    /**
     * return reserved seats in travel
     *
     * @param Travel $travel
     * @return Collection
     */
    static function reserved_seat(Travel $travel) :Collection
    {
        $reserved_seat_2d_collection=$travel->travelReservations->map(function ($item) {
            if ($item->status == 'canceled'){
                return [];
            }
            $seat_numbers=$item->tickets->where('canceled_at',null)->map(function ($item) {
                return $item->seat_number;
            });
            return $seat_numbers;
        });
        $reserved_seat=$reserved_seat_2d_collection->flatten();
        return $reserved_seat;
    }

    /**
     * return number of seats in travel
     *
     * @param Travel $travel
     * @return int
     */
    static function reserved_seat_count(Travel $travel) :int
    {
        return travelHelper::reserved_seat($travel)->count();
    }

    /**
     * return available seats in travel
     *
     *
     * @param Travel $travel
     * @return Collection
     */
    static function available_seats(Travel $travel):Collection
    {
        $all_seats=range(1,$travel->travelable->capacity);
        $reserved_seat = TravelHelper::reserved_seat($travel)->toArray();

        $available_seats=array_diff($all_seats,$reserved_seat);
        return collect($available_seats);
    }

    /**
     * make an output array from travel
     *
     * @param Travel $travel
     * @return array
     */
    static function return_output_of_travel(Travel $travel): array
    {
        $reserved_seat_count=\App\helper\travelHelper::reserved_seat_count($travel);
        return [
            'id' => $travel->id,
            'origin_city_code' => $travel->travelable->origin_city_code,
            'origin_terminal_code' => $travel->travelable->origin_terminal_code,
            'destination_city_code' => $travel->travelable->destination_city_code,
            'destination_terminal_code' => $travel->travelable->destination_terminal_code,
            'day_of_week' => $travel->date->dayOfWeek,
            'departure_date' => $travel->date->format('Y-m-d'),
            'departure_hour' => $travel->date->format('H'),
            'capacity' => $travel->travelable->capacity,
            'available_capacity' => $travel->travelable->capacity - $reserved_seat_count,
            'vehicle_type' => $travel->travelable->type,
            'ticket_price' => $travel->travelable->ticket_price,
            'approximate_arrival_time'=> $travel->date->addMinutes($travel->travelable->approximate_travel_time)->format('Y-m-d H:i'),
            'available_seat'=>\App\helper\travelHelper::available_seats($travel)
        ];
    }


}
