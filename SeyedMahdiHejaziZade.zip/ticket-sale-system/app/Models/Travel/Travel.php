<?php

namespace App\Models\Travel;

use App\Models\Ticket;
use App\Models\TravelReservation;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Travel extends Model
{
    use HasFactory;
    public $timestamps=false;
    protected $fillable=['date','status'];

    protected $casts = [
        'date' => 'datetime',
    ];

    /**
     * Get the parent travelable model (WeeklyBusSchedule or ... ). for implementing train , airplane
     * show type of travel
     */
    public function travelable(): MorphTo
    {
        return $this->morphTo();
    }


    public function travelReservations(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(TravelReservation::class);
    }


    public function tickets(): \Illuminate\Database\Eloquent\Relations\HasManyThrough
    {
        return $this->hasManyThrough(Ticket::class, TravelReservation::class)->where('tickets.canceled_at',false)->wherePivot('status', 'done');
    }
}
