<?php

namespace App\Models;

use App\Models\Travel\Travel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory;
    protected $fillable=['seat_number','name','family','national_code','phone_number','canceled_at'];

    public function travelReservation(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(TravelReservation::class);
    }

}
