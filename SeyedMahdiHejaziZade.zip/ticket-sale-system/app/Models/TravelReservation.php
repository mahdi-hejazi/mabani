<?php

namespace App\Models;

use App\Models\Travel\Travel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TravelReservation extends Model
{
    use HasFactory;
    protected $fillable=[
        'status'
    ];

    public function tickets(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Ticket::class);
    }


    public function travel(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Travel::class);
    }
}
