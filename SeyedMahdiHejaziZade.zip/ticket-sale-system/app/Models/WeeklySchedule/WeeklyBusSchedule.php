<?php

namespace App\Models\WeeklySchedule;

use App\Models\Travel\Travel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class WeeklyBusSchedule extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $fillable=['origin_city_code','origin_terminal_code','destination_city_code','destination_terminal_code','bus_departure_day',
        'bus_departure_time','approximate_travel_time','capacity','type','ticket_price'];

    public function travels():MorphMany
    {
        return $this->morphMany(Travel::class,'travelable');
    }
}
