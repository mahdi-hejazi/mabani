<?php

namespace App\Http\Controllers;

use App\Models\Ticket;
use App\Models\Travel\Travel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TicketController extends Controller
{
    public function cancel(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id' => ['required' , 'integer','exists:tickets,id'],
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }


        $ticket=Ticket::find($request->id);
        $ticket->canceled_at=now();
        $ticket->save();


        if ($ticket->travelReservation->travel->status == 'done'){
            return response()->json('travel is done . we can not cancel ticked', 400);
        }

        return response()->json('ticked canceled', 200);
    }
}
