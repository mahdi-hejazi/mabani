<?php

namespace App\Http\Controllers;

use App\helper\travelHelper;
use App\Models\Ticket;
use App\Models\Travel\Travel;
use App\Models\TravelReservation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TrackingController extends Controller
{

    public function track(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'travel_id' => ['required_without_all:reserve_id,ticket_id' , 'integer','exists:travel,id'],
            'reserve_id' => ['required_without_all:travel_id,ticket_id' , 'integer','exists:travel_reservations,id'],
            'ticket_id' => ['required_without_all:reserve_id,travel_id' , 'integer','exists:tickets,id'],
        ]);
        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

//        for travel_id
        if (request()->has('travel_id')) {
            $travel=Travel::find(request()->travel_id);
            $travel_output=travelHelper::return_output_of_travel($travel);

            return response()->json($travel_output);
        }

//        for reserve_id
        if (request()->has('reserve_id')) {
            $travel_reservation=TravelReservation::find(request()->reserve_id);
            $travel=$travel_reservation->travel;


            $travel_output=travelHelper::return_output_of_travel($travel);
            return response()->json([
                'status' => $travel_reservation->status,
                'travel'=>$travel_output
            ]);
        }


//        for ticket_id
        if (request()->has('ticket_id')) {
            $ticket=Ticket::find($request->ticket_id);
            $travel=$ticket->travelReservation->travel;


            $travel_output=travelHelper::return_output_of_travel($travel);
            return response()->json([
                'id' => $ticket->id,
                'name' => $ticket->name,
                'family' => $ticket->family,
                'national_code' => $ticket->national_code,
                'phone_number' => $ticket->phone_number,
                'travel'=>$travel_output
            ]);
        }

        return response()->json();
    }
}
