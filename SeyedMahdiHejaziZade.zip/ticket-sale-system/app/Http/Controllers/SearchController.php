<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Validator;

class SearchController extends Controller
{
    public function search(Request $request){
        $validator = Validator::make($request->all(), [
            'origin' => ['required' , 'string','max:5'],
            'destination' => ['required' , 'string','max:5'],
            'date' => ['required','integer' ],
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $dateCarbon=Carbon::createFromTimestamp($request->date)->toDateTimeString();

        // Retrieve travel matching the inputs
        $data = \App\Models\Travel\Travel::with('travelable')
            ->whereHasMorph('travelable', \App\Models\WeeklySchedule\WeeklyBusSchedule::class, function ($query) use ($request) {
                $query->where(function ($query) use ($request) {
                    $query->where('origin_city_code', $request->origin)
                        ->orWhere('origin_terminal_code', $request->origin);
                })
                    ->where(function ($query) use ($request) {
                        $query->where('destination_city_code', $request->destination)
                            ->orWhere('destination_terminal_code', $request->destination);
                    });
            })
            ->where('date', $dateCarbon)
            ->get();

        //make output
        $output_data=$data->map(function ($item) {
            $reserved_seat_count=\App\helper\travelHelper::reserved_seat_count($item);
            return [
                'id' => $item->id,
                'origin_city_code' => $item->travelable->origin_city_code,
                'origin_terminal_code' => $item->travelable->origin_terminal_code,
                'destination_city_code' => $item->travelable->destination_city_code,
                'destination_terminal_code' => $item->travelable->destination_terminal_code,
                'day_of_week' => $item->date->dayOfWeek,
                'departure_date' => $item->date->format('Y-m-d'),
                'departure_hour' => $item->date->format('H'),
                'capacity' => $item->travelable->capacity,
                'available_capacity' => $item->travelable->capacity - $reserved_seat_count,
                'vehicle_type' => $item->travelable->type,
                'ticket_price' => $item->travelable->ticket_price,
                'approximate_arrival_time'=> $item->date->addMinutes($item->travelable->approximate_travel_time)->format('Y-m-d H:i'),
                'available_seat'=>\App\helper\travelHelper::available_seats($item)
            ];
        });


        return response()->json($output_data);
    }


}
