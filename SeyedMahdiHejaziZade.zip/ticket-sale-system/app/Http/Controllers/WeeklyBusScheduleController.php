<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class WeeklyBusScheduleController extends Controller
{
    public function origins()
    {
        $data=\App\Models\WeeklySchedule\WeeklyBusSchedule::select('origin_city_code as city_code')->groupBy('city_code')->get();
        return response()->json($data);
    }

    public function destinations()
    {
        $data=\App\Models\WeeklySchedule\WeeklyBusSchedule::select('destination_city_code as city_code')->groupBy('city_code')->get();
        return response()->json($data);
    }

    public function terminals(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'city_code' => ['required' , 'string','max:5']
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $data_o=\App\Models\WeeklySchedule\WeeklyBusSchedule::select('origin_city_code as city_code','origin_terminal_code as terminal_code')
            ->where('origin_city_code',$request->city_code)->get();

        $data_d=\App\Models\WeeklySchedule\WeeklyBusSchedule::select('destination_city_code as city_code ','destination_terminal_code as terminal_code')
            ->orWhere('destination_city_code',$request->city_code)->get();

        $data=$data_o->concat($data_d);
        $data=$data->unique('terminal_code')->values()->all();

        return response()->json($data);
    }
}
