<?php

namespace App\Http\Controllers;

use App\Events\TravelReservationCreated;
use App\Models\Travel\Travel;
use App\Models\TravelReservation;
use http\Env\Response;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ReserveController extends Controller
{

    /**
     * reserve a travel
     *
     * @return JsonResponse
     */
    public function reserve(Request $request){
        $validator = Validator::make($request->all(), [
            'travel_id' => ['required' , 'integer','exists:travel,id'],
            'number_of_passengers' => ['required' , 'integer','min:0'],
            'seat_numbers' => ['required','array','min:1' ],
            'seat_numbers.*' => ['required','integer','min:0'],
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $travel=Travel::whereId($request->travel_id)->with('travelReservations')->first();

        $available_seats=\App\helper\travelHelper::available_seats($travel);

        //check seat numbers are available
        if(!collect(request('seat_numbers'))->diff($available_seats)->isEmpty())
        {
            return response()->json('seat numbers are not available', 400);
        }

        $travel_reservation=$travel->travelReservations()->create();

        // Fire the reservation created event to cancel not complete reservation after 15 min
        event(new TravelReservationCreated($travel_reservation));

        $tickets_input=collect(request('seat_numbers'))->map(function ($item) {
            return [
                'seat_number' => $item,
            ];
        });
        $travel_reservation->tickets()->createMany($tickets_input);

        return response()->json($travel_reservation->id);
    }


    /**
     * cancel reservation
     * make status of reservation cancel
     *
     *
     * @return JsonResponse
     */
    public function cancel(Request $request){
        $validator = Validator::make($request->all(), [
            'id' => ['required' , 'integer','exists:travel_reservations,id'],
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }
        $travel_reservation=TravelReservation::whereId($request->id)->first();
        if ($travel_reservation->status == 'done'){
            return response()->json('reservations is done. we can not cancel it', 400);
        }
        if ($travel_reservation->status == 'canceled'){
            return response()->json('reservations was cancelled', 400);
        }

        $travel_reservation->status = 'canceled';
        $travel_reservation->save();

        return response()->json($travel_reservation->id);
    }

    /**
     * complete reservation ( buy ticket)
     * make status of reservation done
     * complete info of tickets
     *
     * @return JsonResponse
     */
    public function complete(Request $request){
        $validator = Validator::make($request->all(), [
            'reserve_id' => ['required' , 'integer','exists:travel_reservations,id'],

            'passengers' => ['required','array','min:1' ],
            'passengers.*.name' => ['required','string'],
            'passengers.*.family' => ['required','string'],
            'passengers.*.national_code' => ['required','string'],
            'passengers.*.phone_number' => ['required','string'],
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $reservation=TravelReservation::find($request->reserve_id);

//        check not repeat national_codes
        $national_codes_with_tickets =$reservation->travel->tickets->map(function($ticket){

            return $ticket->national_code;
        })->toArray();

        $new_national_codes=collect($request->passengers)->map(function($passenger){return $passenger['national_code'];})->toArray();
        if (array_diff($national_codes_with_tickets,$new_national_codes)){
            return response()->json('passengers national codes repeated', 400);
        }

        //todo do in single query
        $reservation->tickets->each(function($ticket,$index){
            $ticket->name=request('passengers')[$index]['name'];
            $ticket->family=request('passengers')[$index]['family'];
            $ticket->national_code=request('passengers')[$index]['national_code'];
            $ticket->phone_number=request('passengers')[$index]['phone_number'];
            $ticket->save();
        });

        $reservation->status='done';
        $reservation->save();



        $tickets=$reservation->tickets->map(function($ticket){
            return [
                'id'=>$ticket->id,
                'name'=>$ticket->name,
                'family'=>$ticket->family,
                'national_code'=>$ticket->national_code,
                'phone_number'=>$ticket->phone_number,
            ];
        });
        return response()->json($tickets);

    }
}
