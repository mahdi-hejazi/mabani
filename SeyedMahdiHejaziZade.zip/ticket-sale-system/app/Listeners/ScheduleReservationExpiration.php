<?php

namespace App\Listeners;

use App\Events\TravelReservationCreated;
use App\Jobs\ExpireReservation;

class ScheduleReservationExpiration
{
    public function __construct()
    {
        //
    }

    public function handle(TravelReservationCreated $event)
    {
        // Dispatch the job to expire the reservation after 15 minutes
        ExpireReservation::dispatch($event->reservation)->delay(now()->addMinutes(15));
    }
}
