<?php
namespace App\Jobs;

use App\Models\Reservation;
use App\Models\TravelReservation;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ExpireReservation implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $reservation;

    public function __construct(TravelReservation $reservation)
    {
        $this->reservation = $reservation;
    }

    public function handle()
    {
        if ($this->reservation->status == 'booking' && $this->reservation->created_at->diffInMinutes(now()) >= 15) {
            $this->reservation->update(['status' => 'canceled']);
        }
    }
}
