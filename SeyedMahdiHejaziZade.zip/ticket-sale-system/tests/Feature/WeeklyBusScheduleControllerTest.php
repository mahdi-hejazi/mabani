<?php

namespace Tests\Feature;

use App\Models\WeeklySchedule\WeeklyBusSchedule;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class WeeklyBusScheduleControllerTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        // Seed the database with test data
        WeeklyBusSchedule::create([
            'origin_city_code' => 'NYC',
            'origin_terminal_code' => 'T1',
            'destination_city_code' => 'BOS',
            'destination_terminal_code' => 'T2',
            'bus_departure_day' => 1,
            'bus_departure_time' => 36000, // 10:00 AM
            'approximate_travel_time' => 240, // 4 hours
            'capacity' => 50,
            'type' => 'Standard',
            'ticket_price' => 30,
        ]);

        WeeklyBusSchedule::create([
            'origin_city_code' => 'NYC',
            'origin_terminal_code' => 'T3',
            'destination_city_code' => 'PHL',
            'destination_terminal_code' => 'T4',
            'bus_departure_day' => 2,
            'bus_departure_time' => 36000, // 10:00 AM
            'approximate_travel_time' => 120, // 2 hours
            'capacity' => 45,
            'type' => 'Luxury',
            'ticket_price' => 40,
        ]);
    }

    /** @test */
    public function it_can_get_origin_cities()
    {
        $response = $this->json('GET', route('bus.origins'));

        $response->assertStatus(200);
        $response->assertJson([
            ['city_code' => 'NYC'],
        ]);
    }

    /** @test */
    public function it_can_get_destination_cities()
    {
        $response = $this->json('GET', route('bus.destinations'));

        $response->assertStatus(200);
        $response->assertJson([
            ['city_code' => 'BOS'],
            ['city_code' => 'PHL'],
        ]);
    }


}
