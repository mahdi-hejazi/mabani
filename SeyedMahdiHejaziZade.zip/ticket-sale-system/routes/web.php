<?php

use App\Models\WeeklySchedule\WeeklyBusSchedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Validator;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {

//    $data=\App\Models\Travel\Travel::with('travelable')->get();
//    $data=$data->map(function($item){
//        return[
//            ... $item->toArray(),
//            'date'=>$item->date->timestamp
//        ];
//    });

    $data=\App\Models\TravelReservation::all();

    return ($data);
    return 'main page';
});



