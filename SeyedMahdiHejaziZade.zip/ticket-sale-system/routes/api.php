<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Validator;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/


Route::group([ 'prefix' => 'bus'], function () {
    Route::match(['get', 'post'], '/origins',[\App\Http\Controllers\WeeklyBusScheduleController::class,'origins'])->name('bus.origins');
    Route::match(['get', 'post'], '/destinations',[\App\Http\Controllers\WeeklyBusScheduleController::class,'destinations'])->name('bus.destinations');
    Route::match(['get', 'post'], '/terminals', [\App\Http\Controllers\WeeklyBusScheduleController::class,'terminals'])->name('bus.terminals');


    Route::match(['get', 'post'], '/search', [\App\Http\Controllers\SearchController::class,'search'])->name('bus.search');
    Route::post('/reserve',[\App\Http\Controllers\ReserveController::class,'reserve'])->name('bus.reserve');
    Route::post('/reserve/cancel',[\App\Http\Controllers\ReserveController::class,'cancel'])->name('bus.reserve.cancel');

    Route::post('/reserve/complete',[\App\Http\Controllers\ReserveController::class,'complete'])->name('bus.reserve.complete');

    Route::post('/ticket/cancel',[\App\Http\Controllers\TicketController::class,'cancel'])->name('bus.ticket.cancel');
    Route::post('/track',[\App\Http\Controllers\TrackingController::class,'track'])->name('bus.track');
});

